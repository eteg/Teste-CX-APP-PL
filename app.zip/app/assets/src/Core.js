const aNewFunction = () => {
  // A content here
};

const Core = {
  aNewFunction,
};

export default Core;
